package com.betterchatfiltration.filter;

import com.betterchatfiltration.config.FilterConfig;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

public final class FilterRuntime {
	private static volatile Pattern bannedPattern;
	private static volatile Set<String> whitelistedRoots = Set.of();

	private FilterRuntime() {
	}

	public static Pattern bannedPattern() {
		return bannedPattern;
	}

	public static boolean isWhitelisted(String normalizedToken) {
		return whitelistedRoots.contains(normalizedToken);
	}

	public static void rebuild(FilterConfig config) {
		whitelistedRoots = buildWhitelistSet(config.whitelistedWords());
		bannedPattern = compileBannedPattern(config.blacklistedWords());
	}

	private static Set<String> buildWhitelistSet(List<String> words) {
		Set<String> whitelist = new HashSet<>();
		for (String word : words) {
			if (word == null || word.isBlank()) {
				continue;
			}
			String normalized = TextNormalizer.normalizeRoot(word);
			if (!normalized.isEmpty()) {
				whitelist.add(normalized);
			}
		}
		return Set.copyOf(whitelist);
	}

	private static Pattern compileBannedPattern(List<String> words) {
		List<String> escapedRoots = words.stream()
				.filter(word -> word != null && !word.isBlank())
				.map(String::trim)
				.map(TextNormalizer::normalizeRoot)
				.filter(root -> !root.isEmpty())
				.map(Pattern::quote)
				.toList();

		if (escapedRoots.isEmpty()) {
			return null;
		}

		return Pattern.compile("(?iU)(" + String.join("|", escapedRoots) + ")");
	}
}
