package com.betterchatfiltration.filter;

import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;

public final class CensoredWordText {
	private static final String MASK = "****";

	private CensoredWordText() {
	}

	public static class_2561 create(String originalWord) {
		class_2561 hoverText = class_2561.method_43469("betterchatfiltration.censored.hover", originalWord);

		class_2583 censoredStyle = class_2583.field_24360
				.method_10977(class_124.field_1080)
				.method_36141(true)
				.method_10949(new class_2568.class_10613(hoverText))
				.method_10958(new class_2558.class_10606(originalWord));

		return class_2561.method_43470(MASK).method_10862(censoredStyle);
	}
}
