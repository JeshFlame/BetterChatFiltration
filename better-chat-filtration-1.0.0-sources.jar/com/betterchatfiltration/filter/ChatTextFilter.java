package com.betterchatfiltration.filter;

import com.betterchatfiltration.config.FilterConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2588;
import net.minecraft.class_5250;
import net.minecraft.class_7417;
import net.minecraft.class_8828;

public final class ChatTextFilter {
	public static final Logger LOGGER = LoggerFactory.getLogger("VibeFilter");
	private static final Pattern TOKEN_PATTERN = Pattern.compile("[\\p{L}\\p{Nd}]+");

	private ChatTextFilter() {
	}

	public static class_2561 filter(class_2561 message, FilterConfig config) {
		if (!config.enabled()) {
			return message;
		}

		Pattern bannedPattern = FilterRuntime.bannedPattern();
		if (bannedPattern == null) {
			return message;
		}

		return processText(message);
	}

	private static class_2561 processText(class_2561 text) {
		class_7417 content = text.method_10851();
		class_2583 style = text.method_10866();

		LOGGER.info("Анализ узла: " + content.getClass().getSimpleName());

		class_5250 result;

		if (content instanceof class_2588 translatable) {
			Object[] originalArgs = translatable.method_11023();
			Object[] processedArgs = new Object[originalArgs.length];

			for (int index = 0; index < originalArgs.length; index++) {
				processedArgs[index] = processTranslatableArg(originalArgs[index]);
			}

			class_2588 filteredContent = new class_2588(
					translatable.method_11022(),
					translatable.method_48323(),
					processedArgs
			);
			result = class_5250.method_43477(filteredContent).method_10862(style);
		} else if (content instanceof class_8828.class_2585(String literal)) {
			result = filterPlainLiteral(literal, style);
		} else {
			result = (class_5250) text.method_27662().method_10862(style);
		}

		for (class_2561 sibling : text.method_10855()) {
			result.method_10852(processText(sibling));
		}

		return result;
	}

	private static Object processTranslatableArg(Object arg) {
		if (arg instanceof class_2561 textArg) {
			return processText(textArg);
		}

		if (arg instanceof String stringArg) {
			return processText(class_2561.method_43470(stringArg));
		}

		return arg;
	}

	private static class_5250 filterPlainLiteral(String textPart, class_2583 originalStyle) {
		Pattern bannedPattern = FilterRuntime.bannedPattern();
		if (bannedPattern == null) {
			return class_2561.method_43470(textPart).method_10862(originalStyle);
		}

		Matcher tokenMatcher = TOKEN_PATTERN.matcher(textPart);
		if (!tokenMatcher.find()) {
			return class_2561.method_43470(textPart).method_10862(originalStyle);
		}

		tokenMatcher.reset();

		class_5250 result = class_2561.method_43473();
		StringBuilder splitLog = new StringBuilder();
		int lastEnd = 0;
		boolean censored = false;

		LOGGER.info("Оригинал: '{}'", textPart);

		while (tokenMatcher.find()) {
			if (tokenMatcher.start() > lastEnd) {
				String plainChunk = textPart.substring(lastEnd, tokenMatcher.start());
				result.method_10852(class_2561.method_43470(plainChunk).method_10862(originalStyle));
				splitLog.append("[обычный='").append(plainChunk).append("'] ");
			}

			String token = tokenMatcher.group();
			String normalizedToken = TextNormalizer.normalize(token);

			if (FilterRuntime.isWhitelisted(normalizedToken)) {
				result.method_10852(class_2561.method_43470(token).method_10862(originalStyle));
				splitLog.append("[whitelist='").append(token).append("'] ");
			} else if (!normalizedToken.isEmpty() && bannedPattern.matcher(normalizedToken).find()) {
				result.method_10852(CensoredWordText.create(token));
				splitLog.append("[цензура='").append(token).append("->****'] ");
				censored = true;
			} else {
				result.method_10852(class_2561.method_43470(token).method_10862(originalStyle));
				splitLog.append("[обычный='").append(token).append("'] ");
			}

			lastEnd = tokenMatcher.end();
		}

		if (lastEnd < textPart.length()) {
			String tail = textPart.substring(lastEnd);
			result.method_10852(class_2561.method_43470(tail).method_10862(originalStyle));
			splitLog.append("[обычный='").append(tail).append("']");
		}

		if (censored) {
			LOGGER.info("Разбивка: {}", splitLog);
			LOGGER.info("Слово зацензурено!");
		}

		return result;
	}
}
