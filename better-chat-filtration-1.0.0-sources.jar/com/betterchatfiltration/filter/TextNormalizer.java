package com.betterchatfiltration.filter;

import java.util.Locale;

public final class TextNormalizer {
	private TextNormalizer() {
	}

	public static String normalize(String input) {
		if (input == null || input.isEmpty()) {
			return "";
		}

		StringBuilder normalized = new StringBuilder(input.length());
		input.codePoints().forEach(codePoint -> {
			if (Character.isLetter(codePoint)) {
				normalized.appendCodePoint(Character.toLowerCase(codePoint));
			}
		});
		return normalized.toString();
	}

	public static String normalizeRoot(String root) {
		return normalize(root).trim();
	}
}
