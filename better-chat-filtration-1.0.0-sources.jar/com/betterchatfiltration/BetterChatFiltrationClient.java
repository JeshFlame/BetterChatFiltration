package com.betterchatfiltration;

import com.betterchatfiltration.command.ChatFilterCommands;
import com.betterchatfiltration.config.FilterConfigManager;
import com.betterchatfiltration.input.ChatFilterKeyBindings;
import com.betterchatfiltration.ui.ChatFilterConfigScreen;
import com.betterchatfiltration.update.UpdateChecker;
import com.betterchatfiltration.util.ClientMessages;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BetterChatFiltrationClient implements ClientModInitializer {
	public static final String MOD_ID = "betterchatfiltration";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitializeClient() {
		FilterConfigManager.load();
		ChatFilterKeyBindings.register();
		ChatFilterCommands.register();

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (ChatFilterKeyBindings.openSettingsKey.method_1436()) {
				client.method_1507(ChatFilterConfigScreen.create(client.field_1755));
			}
		});

		ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
			client.execute(() -> {
				ClientMessages.sendWelcome(client);
				UpdateChecker.checkAsync(client);
			});
		});

		LOGGER.info("Chat Filter initialized. Blacklisted roots: {}", FilterConfigManager.get().blacklistedWords().size());
	}
}
