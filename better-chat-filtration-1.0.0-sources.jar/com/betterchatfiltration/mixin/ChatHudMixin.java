package com.betterchatfiltration.mixin;

import com.betterchatfiltration.config.FilterConfigManager;
import com.betterchatfiltration.filter.ChatTextFilter;
import net.minecraft.class_2561;
import net.minecraft.class_338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_338.class)
public abstract class ChatHudMixin {
	@ModifyVariable(
			method = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V",
			at = @At("HEAD"),
			index = 1
	)
	private class_2561 betterchatfiltration$filterSignedMessage(class_2561 message) {
		ChatTextFilter.LOGGER.info("Проверка сообщения: " + message.getString());
		return ChatTextFilter.filter(message, FilterConfigManager.get());
	}
}
