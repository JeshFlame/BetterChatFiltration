package com.betterchatfiltration.command;

import com.betterchatfiltration.config.FilterConfigManager;
import com.mojang.brigadier.Command;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.class_2561;

public final class ChatFilterCommands {
	private ChatFilterCommands() {
	}

	public static void register() {
		ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> dispatcher.register(
				ClientCommandManager.literal("cf")
						.then(ClientCommandManager.literal("on").executes(context -> {
							FilterConfigManager.setEnabled(true);
							sendFeedback(class_2561.method_43471("betterchatfiltration.command.enabled"));
							return Command.SINGLE_SUCCESS;
						}))
						.then(ClientCommandManager.literal("off").executes(context -> {
							FilterConfigManager.setEnabled(false);
							sendFeedback(class_2561.method_43471("betterchatfiltration.command.disabled"));
							return Command.SINGLE_SUCCESS;
						}))
						.then(ClientCommandManager.literal("reload").executes(context -> {
							FilterConfigManager.reload();
							sendFeedback(class_2561.method_43471("betterchatfiltration.command.reloaded"));
							return Command.SINGLE_SUCCESS;
						}))
		));
	}

	private static void sendFeedback(class_2561 message) {
		net.minecraft.class_310.method_1551().field_1705.method_1743().method_1812(message);
	}
}
