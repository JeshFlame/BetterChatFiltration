package com.betterchatfiltration.input;

import com.betterchatfiltration.BetterChatFiltrationClient;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public final class ChatFilterKeyBindings {
	public static class_304 openSettingsKey;

	private ChatFilterKeyBindings() {
	}

	public static void register() {
		openSettingsKey = KeyBindingHelper.registerKeyBinding(new class_304(
				"key.betterchatfiltration.open_settings",
				class_3675.class_307.field_1668,
				GLFW.GLFW_KEY_F8,
				class_304.class_11900.field_62556
		));
	}
}
