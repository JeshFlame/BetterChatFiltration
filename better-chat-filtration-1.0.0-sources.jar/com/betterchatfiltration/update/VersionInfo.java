package com.betterchatfiltration.update;

public record VersionInfo(String latestVersion, String downloadUrl) {
}
