package com.betterchatfiltration.update;

import com.betterchatfiltration.BetterChatFiltrationClient;
import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;

public final class UpdateChecker {
	private static final Gson GSON = new Gson();
	private static final String VERSION_URL = "https://raw.githubusercontent.com/JeshFlame/BetterChatFiltration/main/version.json";

	private UpdateChecker() {
	}

	public static void checkAsync(class_310 client) {
		CompletableFuture.runAsync(() -> {
			VersionInfo versionInfo = fetchLatestVersion();
			if (versionInfo == null) {
				return;
			}

			String currentVersion = FabricLoader.getInstance().getModContainer(BetterChatFiltrationClient.MOD_ID)
					.map(container -> container.getMetadata().getVersion().getFriendlyString())
					.orElse("0.0.0");

			if (!isNewer(versionInfo.latestVersion(), currentVersion)) {
				return;
			}

			client.execute(() -> sendUpdateMessage(client, versionInfo, currentVersion));
		});
	}

	private static VersionInfo fetchLatestVersion() {
		try (InputStreamReader reader = new InputStreamReader(new URL(VERSION_URL).openStream(), StandardCharsets.UTF_8)) {
			RemoteVersion remoteVersion = GSON.fromJson(reader, RemoteVersion.class);
			if (remoteVersion == null || remoteVersion.latestVersion == null || remoteVersion.downloadUrl == null) {
				return null;
			}
			return new VersionInfo(remoteVersion.latestVersion, remoteVersion.downloadUrl);
		} catch (IOException exception) {
			BetterChatFiltrationClient.LOGGER.warn("Failed to check for updates", exception);
			return null;
		}
	}

	private static void sendUpdateMessage(class_310 client, VersionInfo versionInfo, String currentVersion) {
		if (client.field_1724 == null) {
			return;
		}

		class_2561 updateLink = class_2561.method_43469("betterchatfiltration.update.download", versionInfo.latestVersion())
				.method_27694(style -> style
						.method_10977(class_124.field_1060)
						.method_30938(true)
						.method_10958(new class_2558.class_10608(URI.create(versionInfo.downloadUrl()))));

		client.field_1705.method_1743().method_1812(
				class_2561.method_43470("[Chat Filter] ")
						.method_27692(class_124.field_1075)
						.method_10852(class_2561.method_43469(
								"betterchatfiltration.update.available",
								currentVersion,
								versionInfo.latestVersion()
						))
						.method_10852(updateLink)
		);
	}

	private static boolean isNewer(String latest, String current) {
		String[] latestParts = latest.split("\\.");
		String[] currentParts = current.split("\\.");
		int length = Math.max(latestParts.length, currentParts.length);

		for (int index = 0; index < length; index++) {
			int latestPart = index < latestParts.length ? parsePart(latestParts[index]) : 0;
			int currentPart = index < currentParts.length ? parsePart(currentParts[index]) : 0;
			if (latestPart > currentPart) {
				return true;
			}
			if (latestPart < currentPart) {
				return false;
			}
		}

		return false;
	}

	private static int parsePart(String part) {
		try {
			return Integer.parseInt(part.replaceAll("[^0-9]", ""));
		} catch (NumberFormatException exception) {
			return 0;
		}
	}

	private static final class RemoteVersion {
		@SerializedName("latest_version")
		String latestVersion;

		@SerializedName("download_url")
		String downloadUrl;
	}
}
