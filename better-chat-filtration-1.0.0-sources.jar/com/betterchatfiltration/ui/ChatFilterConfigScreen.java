package com.betterchatfiltration.ui;

import com.betterchatfiltration.config.FilterConfig;
import com.betterchatfiltration.config.FilterConfigManager;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_437;
import java.util.ArrayList;

public final class ChatFilterConfigScreen {
	private ChatFilterConfigScreen() {
	}

	public static class_437 create(class_437 parent) {
		FilterConfig current = FilterConfigManager.get();
		WorkingCopy workingCopy = new WorkingCopy(current);

		ConfigBuilder builder = ConfigBuilder.create()
				.setParentScreen(parent)
				.setTitle(class_2561.method_43471("betterchatfiltration.config.title"))
				.setTransparentBackground(false);

		ConfigEntryBuilder entryBuilder = builder.entryBuilder();

		builder.getOrCreateCategory(class_2561.method_43471("betterchatfiltration.config.category.general"))
				.addEntry(entryBuilder.startBooleanToggle(class_2561.method_43471("betterchatfiltration.config.enabled"), workingCopy.enabled)
						.setDefaultValue(true)
						.setTooltip(class_2561.method_43471("betterchatfiltration.config.enabled.tooltip"))
						.setSaveConsumer(value -> workingCopy.enabled = value)
						.build())
				.addEntry(buildWordListSection(
						entryBuilder,
						workingCopy,
						true
				))
				.addEntry(buildWordListSection(
						entryBuilder,
						workingCopy,
						false
				));

		builder.setSavingRunnable(() -> FilterConfigManager.saveAndApply(workingCopy.toConfig()));

		return builder.build();
	}

	private static me.shedaniel.clothconfig2.api.AbstractConfigListEntry<?> buildWordListSection(
			ConfigEntryBuilder entryBuilder,
			WorkingCopy workingCopy,
			boolean blacklist
	) {
		var subCategory = entryBuilder.startSubCategory(blacklist
				? class_2561.method_43471("betterchatfiltration.config.blacklist")
				: class_2561.method_43471("betterchatfiltration.config.whitelist"))
				.setExpanded(true);

		subCategory.add(entryBuilder.startTextDescription(
				class_2561.method_43471("betterchatfiltration.config.list_input_hint").method_27692(class_124.field_1054)
		).build());

		if (blacklist) {
			subCategory.add(entryBuilder.startStrList(
							class_2561.method_43471("betterchatfiltration.config.blacklist.entries"),
							new ArrayList<>(workingCopy.blacklistedWords)
					)
					.setDefaultValue(FilterConfig.defaults().blacklistedWords())
					.setTooltip(class_2561.method_43471("betterchatfiltration.config.blacklist.tooltip"))
					.setSaveConsumer(value -> workingCopy.blacklistedWords = new ArrayList<>(value))
					.build());
		} else {
			subCategory.add(entryBuilder.startStrList(
							class_2561.method_43471("betterchatfiltration.config.whitelist.entries"),
							new ArrayList<>(workingCopy.whitelistedWords)
					)
					.setDefaultValue(FilterConfig.defaults().whitelistedWords())
					.setTooltip(class_2561.method_43471("betterchatfiltration.config.whitelist.tooltip"))
					.setSaveConsumer(value -> workingCopy.whitelistedWords = new ArrayList<>(value))
					.build());
		}

		return subCategory.build();
	}

	private static final class WorkingCopy {
		private boolean enabled;
		private ArrayList<String> blacklistedWords;
		private ArrayList<String> whitelistedWords;

		private WorkingCopy(FilterConfig config) {
			this.enabled = config.enabled();
			this.blacklistedWords = new ArrayList<>(config.blacklistedWords());
			this.whitelistedWords = new ArrayList<>(config.whitelistedWords());
		}

		private FilterConfig toConfig() {
			return new FilterConfig(enabled, blacklistedWords, whitelistedWords);
		}
	}
}
