package com.betterchatfiltration.config;

import com.betterchatfiltration.BetterChatFiltrationClient;
import com.betterchatfiltration.filter.FilterRuntime;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.SerializedName;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public final class FilterConfigManager {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final ReadWriteLock LOCK = new ReentrantReadWriteLock();
	private static FilterConfig config = FilterConfig.defaults();

	private FilterConfigManager() {
	}

	public static FilterConfig get() {
		LOCK.readLock().lock();
		try {
			return config.snapshot();
		} finally {
			LOCK.readLock().unlock();
		}
	}

	public static void load() {
		Path configPath = configPath();

		if (!Files.exists(configPath)) {
			Path legacyPath = legacyConfigPath();
			if (Files.exists(legacyPath)) {
				loadFromPath(legacyPath);
				save();
				return;
			}

			applyConfig(FilterConfig.defaults());
			save();
			return;
		}

		loadFromPath(configPath);
	}

	public static void reload() {
		load();
		BetterChatFiltrationClient.LOGGER.info("Chat Filter config reloaded");
	}

	public static void save() {
		FilterConfig snapshot = get();
		Path configPath = configPath();

		try {
			Files.createDirectories(configPath.getParent());
			FileModel model = FileModel.from(snapshot);
			try (Writer writer = Files.newBufferedWriter(configPath, StandardCharsets.UTF_8)) {
				GSON.toJson(model, writer);
			}
		} catch (IOException exception) {
			BetterChatFiltrationClient.LOGGER.error("Failed to save config", exception);
		}
	}

	public static void saveAndApply(FilterConfig updatedConfig) {
		applyConfig(updatedConfig);
		save();
	}

	public static void setEnabled(boolean enabled) {
		FilterConfig current = get();
		saveAndApply(new FilterConfig(enabled, current.blacklistedWords(), current.whitelistedWords()));
	}

	private static void loadFromPath(Path configPath) {
		try (Reader reader = Files.newBufferedReader(configPath, StandardCharsets.UTF_8)) {
			FileModel model = GSON.fromJson(reader, FileModel.class);
			if (model == null) {
				BetterChatFiltrationClient.LOGGER.warn("Config file is empty, using defaults");
				applyConfig(FilterConfig.defaults());
				return;
			}

			applyConfig(model.toConfig());
		} catch (IOException exception) {
			BetterChatFiltrationClient.LOGGER.error("Failed to read config, using defaults", exception);
			applyConfig(FilterConfig.defaults());
		}
	}

	private static void applyConfig(FilterConfig loadedConfig) {
		LOCK.writeLock().lock();
		try {
			config = new FilterConfig(
					loadedConfig.enabled(),
					new ArrayList<>(loadedConfig.blacklistedWords()),
					new ArrayList<>(loadedConfig.whitelistedWords())
			);
			FilterRuntime.rebuild(config);
		} finally {
			LOCK.writeLock().unlock();
		}
	}

	private static Path configPath() {
		return FabricLoader.getInstance().getConfigDir().resolve("betterchatfiltration.json");
	}

	private static Path legacyConfigPath() {
		return FabricLoader.getInstance().getConfigDir().resolve("filter.json");
	}

	private static final class FileModel {
		@SerializedName("is_enabled")
		Boolean enabled;

		@SerializedName("blacklisted_words")
		List<String> blacklistedWords;

		@SerializedName("whitelisted_words")
		List<String> whitelistedWords;

		@SerializedName("whitelisted_players")
		List<String> legacyWhitelistedPlayers;

		FilterConfig toConfig() {
			List<String> blacklist = blacklistedWords != null
					? new ArrayList<>(blacklistedWords)
					: new ArrayList<>(List.of("даун", "пидр"));

			List<String> whitelist;
			if (whitelistedWords != null) {
				whitelist = new ArrayList<>(whitelistedWords);
			} else if (legacyWhitelistedPlayers != null) {
				whitelist = new ArrayList<>(legacyWhitelistedPlayers);
			} else {
				whitelist = new ArrayList<>();
			}

			return new FilterConfig(enabled != null ? enabled : true, blacklist, whitelist);
		}

		static FileModel from(FilterConfig config) {
			FileModel model = new FileModel();
			model.enabled = config.enabled();
			model.blacklistedWords = new ArrayList<>(config.blacklistedWords());
			model.whitelistedWords = new ArrayList<>(config.whitelistedWords());
			return model;
		}
	}
}
