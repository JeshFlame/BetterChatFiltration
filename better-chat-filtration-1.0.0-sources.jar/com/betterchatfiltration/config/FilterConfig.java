package com.betterchatfiltration.config;

import java.util.List;

public record FilterConfig(
		boolean enabled,
		List<String> blacklistedWords,
		List<String> whitelistedWords
) {
	public static FilterConfig defaults() {
		return new FilterConfig(true, List.of("даун", "пидр"), List.of());
	}

	public FilterConfig snapshot() {
		return new FilterConfig(
				enabled,
				List.copyOf(blacklistedWords),
				List.copyOf(whitelistedWords)
		);
	}
}
