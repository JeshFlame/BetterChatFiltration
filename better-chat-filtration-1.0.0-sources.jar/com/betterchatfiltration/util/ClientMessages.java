package com.betterchatfiltration.util;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public final class ClientMessages {
	private ClientMessages() {
	}

	public static void sendWelcome(class_310 client) {
		if (client.field_1724 == null) {
			return;
		}

		class_2561 command = class_2561.method_43471("betterchatfiltration.welcome.command").method_27692(class_124.field_1054);
		class_2561 key = class_2561.method_43471("betterchatfiltration.welcome.key").method_27692(class_124.field_1054);

		client.field_1705.method_1743().method_1812(
				class_2561.method_43470("[Chat Filter] ")
						.method_27692(class_124.field_1075)
						.method_10852(class_2561.method_43469("betterchatfiltration.welcome", command, key))
		);
	}
}
